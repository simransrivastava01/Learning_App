class PostedC
{
   String image,description,date,time;
   PostedC(this.image,this.description,this.date,this.time);
}